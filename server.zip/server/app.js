// app.js
const express = require('express');
const db = require('./db');
const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());

// 간단한 GET 라우트
app.get('/api/goals', async (req, res) => {
    try {
        const result = await db.query('SELECT * FROM goals');
        res.json(result.rows);
    } catch (error) {
        console.error(error);
        res.status(500).send('Server Error');
    }
});



// 날짜에 따른 GET 라우트
app.get('/api/goals/:date', async (req, res) => {
    const { date } = req.params; // URL 파라미터에서 userId 추출
    try {
        const result = await db.query(
            'SELECT * FROM goals WHERE date = $1',
            [date] // date SQL 쿼리에 바인딩
        );
        res.json(result.rows);
    } catch (error) {
        console.error(error);
        res.status(500).send('Server Error');
    }
});



// POST 라우트 (데이터 삽입)
app.post('/api/goals', async (req, res) => {
    const { title, description, date } = req.body; // title, description, checked, date 추출
    try {
        const result = await db.query(
            'INSERT INTO goals (title, description, checked, date) VALUES ($1, $2, $3, $4) RETURNING *',
            [title, description, 'false', date] // 각각의 값을 배열로 전달
        );
        res.status(201).json(result.rows[0]);
    } catch (error) {
        console.error(error);
        res.status(500).send('Server Error');
    }
});

app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});


